# mack_loadingscreen

## ⚙️ How to Install  
- Download mack_loadingscreen (https://github.com/Mackgame4/mack_loadingscreen) and drop in your "resources" folder  
- Add to your server.cfg, the following line: ```ensure mack_loadingscreen```  
- Just start your server and have fun  

## 📷 Screenshots  
Screenshot: https://i.imgur.com/1v3Nmxb.png  
Video: https://streamable.com/gaix12  

## 🔖 Attention:  
mack_loadingscreen is a loadingscreen by [Mackgame4](https://github.com/Mackgame4) created based on [TFRP_Loadingscreen](https://forum.cfx.re/t/release-tfrp-nopixel-loading-screen-modification-new-version-kingrich-importanthippo/202859) by [KingRich](https://github.com/KingRich-TLFRP/TFRP_loadingscreen)

## ☁️ Download:  
[Here](https://github.com/Mackgame4/mack_loadingscreen) or Github (https://github.com/Mackgame4/mack_loadingscreen)  
Join our [Discord](https://discord.gg/As3VMTb) or in (https://discord.io/mack)  
### Creators: Mackgame4 & KingRich (Portugal❤️Italy)
